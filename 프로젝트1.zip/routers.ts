import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { createAnalysis, getUserAnalysisHistory, getAnalysisById, createSharedResult, getSharedResultByToken } from "./db";
import { analyzeImage } from "./analysis";
import { nanoid } from "nanoid";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  analysis: router({
    /**
     * Analyze image via URL or uploaded file
     */
    analyze: protectedProcedure
      .input(
        z.object({
          imageUrl: z.string().url(),
          detectionMethod: z.enum(["upload", "url"]),
        })
      )
      .mutation(async ({ ctx, input }) => {
        // Analyze the image using LLM
        const analysisResult = await analyzeImage(input.imageUrl);

        // Save to database
        const result = await createAnalysis({
          userId: ctx.user.id,
          imageUrl: input.imageUrl,
          aiProbability: analysisResult.aiProbability,
          confidence: analysisResult.confidence,
          analysis: analysisResult.analysis,
          detectionMethod: input.detectionMethod,
        });

        return {
          id: (result as any).insertId,
          aiProbability: analysisResult.aiProbability,
          confidence: analysisResult.confidence,
          analysis: analysisResult.analysis,
        };
      }),

    /**
     * Get analysis history for current user
     */
    history: protectedProcedure
      .input(
        z.object({
          limit: z.number().default(20),
          offset: z.number().default(0),
        })
      )
      .query(async ({ ctx, input }) => {
        return getUserAnalysisHistory(ctx.user.id, input.limit, input.offset);
      }),

    /**
     * Get specific analysis by ID
     */
    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return getAnalysisById(input.id);
      }),

    /**
     * Create a shareable link for analysis result
     */
    createShare: protectedProcedure
      .input(
        z.object({
          analysisId: z.number(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const shareToken = nanoid(32);
        await createSharedResult({
          shareToken,
          analysisId: input.analysisId,
          userId: ctx.user.id,
        });

        return { shareToken };
      }),

    /**
     * Get shared analysis result by token
     */
    getShared: publicProcedure
      .input(
        z.object({
          shareToken: z.string(),
        })
      )
      .query(async ({ input }) => {
        const result = await getSharedResultByToken(input.shareToken);
        if (!result) {
          throw new Error("Shared result not found");
        }

        const analysis = (result as any).analysisHistory;
        return {
          aiProbability: analysis.aiProbability,
          confidence: analysis.confidence,
          analysis: analysis.analysis,
          imageUrl: analysis.imageUrl,
          analysisId: analysis.id,
          sharedAt: (result as any).sharedResults.createdAt,
        };
      }),
  }),
});

export type AppRouter = typeof appRouter;

import { useState, useEffect } from 'react';
import { X, Zap, Infinity, Layers, Headphones, HardDrive } from 'lucide-react';

interface ProUpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ProUpgradeModal({ isOpen, onClose }: ProUpgradeModalProps) {
  const [hideToday, setHideToday] = useState(false);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (isOpen) {
      // Small delay for animation
      setTimeout(() => setIsVisible(true), 10);
      document.body.style.overflow = 'hidden';
    } else {
      setIsVisible(false);
      document.body.style.overflow = 'unset';
    }

    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  const handleNotYet = () => {
    if (hideToday) {
      const today = new Date().toDateString();
      localStorage.setItem('proUpgradeHideUntil', today);
    }
    onClose();
  };

  const handleGetPro = () => {
    console.log('Get Pro clicked');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 md:p-8">
      {/* Enhanced Backdrop */}
      <div
        className={`absolute inset-0 transition-all duration-500 ${
          isVisible ? 'bg-black/95 backdrop-blur-lg' : 'bg-black/0 backdrop-blur-none'
        }`}
        onClick={onClose}
      />

      {/* Modal Container */}
      <div
        className={`relative w-full max-w-sm sm:max-w-md h-[85vh] sm:h-[90vh] max-h-[600px] sm:max-h-[700px] transform transition-all duration-500 flex flex-col z-10 ${
          isVisible ? 'scale-100 opacity-100' : 'scale-95 opacity-0'
        }`}
      >
        {/* Glow Effect Background */}
        <div className="absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 via-transparent to-purple-500/20 rounded-3xl blur-3xl" />
        </div>

        {/* Main Modal */}
        <div className="relative bg-gradient-to-br from-slate-900 via-slate-900 to-slate-800 rounded-3xl shadow-2xl overflow-hidden border border-blue-500/40 flex flex-col h-full">
          {/* Animated Border Gradient */}
          <div className="absolute inset-0 rounded-3xl p-px bg-gradient-to-r from-blue-500/50 via-purple-500/30 to-blue-500/50 -z-10" />

          {/* Close Button */}
          <button
            onClick={onClose}
            className="absolute top-6 right-6 z-20 p-2 hover:bg-slate-800/80 rounded-full transition-all duration-300 group"
          >
            <X className="w-5 h-5 text-slate-400 group-hover:text-white group-hover:scale-110 transition-all" />
          </button>

          {/* Scrollable Content Container */}
          <div className="flex-1 overflow-y-auto scrollbar-hide">
          {/* Header Section */}
          <div className="relative overflow-hidden pt-12 pb-8 px-8 text-center">
            {/* Animated Background */}
            <div className="absolute inset-0 opacity-40">
              <div
                className="absolute inset-0"
                style={{
                  background:
                    'radial-gradient(circle at 50% 0%, rgba(59, 130, 246, 0.4), transparent 70%)',
                }}
              />
            </div>

            <div className="relative z-10">
              {/* Premium Badge */}
              <div className="inline-flex items-center gap-2 mb-4 px-4 py-2 rounded-full bg-gradient-to-r from-blue-500/30 to-purple-500/30 border border-blue-400/50 backdrop-blur-sm">
                <Zap className="w-4 h-4 text-blue-300" />
                <span className="text-xs font-bold text-blue-200 tracking-wider">
                  ✨ PREMIUM EXPERIENCE
                </span>
              </div>

              {/* Title */}
              <h2 className="text-4xl font-bold mb-3 bg-gradient-to-r from-blue-300 via-blue-200 to-cyan-300 bg-clip-text text-transparent">
                Pro로 업그레이드
              </h2>

              {/* Subtitle */}
              <p className="text-slate-300 text-sm font-medium">
                더 강력한 AI 분석 능력을 경험하세요
              </p>
            </div>
          </div>

          {/* Features Section */}
          <div className="px-8 py-8 space-y-4 bg-gradient-to-b from-transparent via-slate-900/50 to-slate-800/50">
            {/* Feature 1 */}
            <div className="flex items-start gap-4 group">
              <div className="flex-shrink-0 mt-1">
                <div className="flex items-center justify-center h-10 w-10 rounded-xl bg-gradient-to-br from-blue-500/30 to-cyan-500/20 border border-blue-400/50 group-hover:from-blue-500/50 group-hover:to-cyan-500/40 transition-all">
                  <Infinity className="w-5 h-5 text-blue-300" />
                </div>
              </div>
              <div className="flex-1">
                <p className="text-sm font-semibold text-white mb-1">무제한 분석</p>
                <p className="text-xs text-slate-400">매일 최대 1,000개 이미지 분석 가능</p>
              </div>
            </div>

            {/* Feature 2 */}
            <div className="flex items-start gap-4 group">
              <div className="flex-shrink-0 mt-1">
                <div className="flex items-center justify-center h-10 w-10 rounded-xl bg-gradient-to-br from-purple-500/30 to-pink-500/20 border border-purple-400/50 group-hover:from-purple-500/50 group-hover:to-pink-500/40 transition-all">
                  <Zap className="w-5 h-5 text-purple-300" />
                </div>
              </div>
              <div className="flex-1">
                <p className="text-sm font-semibold text-white mb-1">고급 분석</p>
                <p className="text-xs text-slate-400">AI 생성 이미지 99.8% 정확도 판별</p>
              </div>
            </div>

            {/* Feature 3 */}
            <div className="flex items-start gap-4 group">
              <div className="flex-shrink-0 mt-1">
                <div className="flex items-center justify-center h-10 w-10 rounded-xl bg-gradient-to-br from-cyan-500/30 to-blue-500/20 border border-cyan-400/50 group-hover:from-cyan-500/50 group-hover:to-blue-500/40 transition-all">
                  <Layers className="w-5 h-5 text-cyan-300" />
                </div>
              </div>
              <div className="flex-1">
                <p className="text-sm font-semibold text-white mb-1">일괄 분석</p>
                <p className="text-xs text-slate-400">최대 100개 이미지를 한 번에 분석</p>
              </div>
            </div>

            {/* Feature 4 */}
            <div className="flex items-start gap-4 group">
              <div className="flex-shrink-0 mt-1">
                <div className="flex items-center justify-center h-10 w-10 rounded-xl bg-gradient-to-br from-orange-500/30 to-red-500/20 border border-orange-400/50 group-hover:from-orange-500/50 group-hover:to-red-500/40 transition-all">
                  <Headphones className="w-5 h-5 text-orange-300" />
                </div>
              </div>
              <div className="flex-1">
                <p className="text-sm font-semibold text-white mb-1">우선 지원</p>
                <p className="text-xs text-slate-400">24시간 전담 고객 지원 서비스</p>
              </div>
            </div>

            {/* Feature 5 */}
            <div className="flex items-start gap-4 group">
              <div className="flex-shrink-0 mt-1">
                <div className="flex items-center justify-center h-10 w-10 rounded-xl bg-gradient-to-br from-green-500/30 to-emerald-500/20 border border-green-400/50 group-hover:from-green-500/50 group-hover:to-emerald-500/40 transition-all">
                  <HardDrive className="w-5 h-5 text-green-300" />
                </div>
              </div>
              <div className="flex-1">
                <p className="text-sm font-semibold text-white mb-1">대용량 지원</p>
                <p className="text-xs text-slate-400">최대 100MB까지 이미지 분석 지원</p>
              </div>
            </div>
          </div>

          {/* Price Section */}
          <div className="px-8 py-6 bg-gradient-to-r from-blue-500/10 via-purple-500/5 to-blue-500/10 border-y border-blue-500/20">
            <div className="text-center">
              <p className="text-xs text-slate-400 font-medium mb-2 tracking-wide">
                월간 구독 요금
              </p>
              <div className="flex items-baseline justify-center gap-1">
                <span className="text-4xl font-bold text-white">$9.99</span>
                <span className="text-slate-400 font-medium">/월</span>
              </div>
              <p className="text-xs text-slate-500 mt-2">
                언제든지 취소 가능 · 신용카드 필수
              </p>
            </div>
          </div>

          </div>
          {/* End Scrollable Content */}

          {/* Buttons Section */}
          <div className="px-8 py-8 space-y-3 flex-shrink-0 bg-gradient-to-t from-slate-900 via-slate-900/80 to-transparent">
            {/* Get Pro Button */}
            <button
              onClick={handleGetPro}
              className="w-full py-4 px-4 rounded-xl font-bold text-white transition-all duration-300 relative overflow-hidden group"
              style={{
                background: 'linear-gradient(135deg, #3b82f6 0%, #60a5fa 50%, #06b6d4 100%)',
                boxShadow: '0 0 30px rgba(59, 130, 246, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.2)',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.boxShadow =
                  '0 0 60px rgba(59, 130, 246, 0.8), 0 0 100px rgba(6, 182, 212, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.3)';
                e.currentTarget.style.transform = 'translateY(-2px)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.boxShadow =
                  '0 0 30px rgba(59, 130, 246, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.2)';
                e.currentTarget.style.transform = 'translateY(0)';
              }}
            >
              <span className="relative z-10 flex items-center justify-center gap-2">
                <Zap className="w-5 h-5" />
                Get Pro 지금 시작하기
              </span>
            </button>

            {/* Not Yet Button */}
            <button
              onClick={handleNotYet}
              className="w-full py-3 px-4 rounded-xl font-semibold text-slate-300 bg-slate-800/60 border border-slate-700/60 hover:bg-slate-800 hover:border-slate-600 transition-all duration-300"
            >
              Not Yet
            </button>

            {/* Hide Today Checkbox */}
            <label className="flex items-center gap-3 cursor-pointer px-2 py-2 rounded-lg hover:bg-slate-800/30 transition-colors">
              <input
                type="checkbox"
                checked={hideToday}
                onChange={(e) => setHideToday(e.target.checked)}
                className="w-4 h-4 rounded border-slate-600 bg-slate-800 cursor-pointer accent-blue-500"
              />
              <span className="text-sm text-slate-400 font-medium">오늘 하루 보지 않기</span>
            </label>
          </div>
        </div>
      </div>
    </div>
  );
}

import { useState, useRef, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card } from "@/components/ui/card";
import { Spinner } from "@/components/ui/spinner";
import { toast } from "sonner";
import { ImageUploadZone } from "@/components/ImageUploadZone";
import { UrlInputForm } from "@/components/UrlInputForm";
import { AnalysisResult } from "@/components/AnalysisResult";
import { AnalysisHistory } from "@/components/AnalysisHistory";
import { WaveBackground } from "@/components/WaveBackground";
import { ProUpgradeModal } from "@/components/ProUpgradeModal";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";
import { LogOut, History } from "lucide-react";

interface AnalysisState {
  id: number;
  aiProbability: number;
  confidence: number;
  analysis: string;
  imageUrl: string;
}

export default function Home() {
  const { user, isAuthenticated, logout } = useAuth();
  const [analysisState, setAnalysisState] = useState<AnalysisState | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [currentImageUrl, setCurrentImageUrl] = useState<string>("");
  const [showProModal, setShowProModal] = useState(false);
  const uploadedFileRef = useRef<File | null>(null);

  // Check if should show Pro modal on first login
  useEffect(() => {
    if (isAuthenticated) {
      const hideUntil = localStorage.getItem('proUpgradeHideUntil');
      const today = new Date().toDateString();
      if (!hideUntil || hideUntil !== today) {
        setShowProModal(true);
      }
    }
  }, [isAuthenticated]);

  // tRPC mutations and queries
  const analyzeMutation = trpc.analysis.analyze.useMutation();
  const historyQuery = trpc.analysis.history.useQuery(
    { limit: 20, offset: 0 },
    { enabled: isAuthenticated }
  );
  const createShareMutation = trpc.analysis.createShare.useMutation();

  // Handle file upload
  const handleImageUpload = async (file: File) => {
    uploadedFileRef.current = file;
    const reader = new FileReader();

    reader.onload = async (e) => {
      const imageUrl = e.target?.result as string;
      setCurrentImageUrl(imageUrl);
      await performAnalysis(imageUrl, "upload");
    };

    reader.readAsDataURL(file);
  };

  // Handle URL input
  const handleUrlSubmit = async (url: string) => {
    setCurrentImageUrl(url);
    await performAnalysis(url, "url");
  };

  // Perform analysis
  const performAnalysis = async (imageUrl: string, method: "upload" | "url") => {
    if (!isAuthenticated) {
      window.location.href = getLoginUrl();
      return;
    }

    setIsAnalyzing(true);
    try {
      const result = await analyzeMutation.mutateAsync({
        imageUrl,
        detectionMethod: method,
      });

      setAnalysisState({
        id: result.id,
        aiProbability: result.aiProbability,
        confidence: result.confidence,
        analysis: result.analysis,
        imageUrl,
      });

      // Invalidate history to refresh
      await historyQuery.refetch();

      toast.success("분석이 완료되었습니다!");
    } catch (error) {
      console.error("Analysis error:", error);
      toast.error("분석 중 오류가 발생했습니다. 다시 시도해주세요.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Handle share
  const handleShare = async (analysisId: string) => {
    try {
      const result = await createShareMutation.mutateAsync({
        analysisId: parseInt(analysisId),
      } as any);

      const shareUrl = `${window.location.origin}/share/${result.shareToken}`;
      await navigator.clipboard.writeText(shareUrl);
      toast.success("공유 링크가 복사되었습니다!");
    } catch (error) {
      console.error("Share error:", error);
      toast.error("공유 링크 생성에 실패했습니다.");
    }
  };

  // Render login prompt
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800 flex items-center justify-center px-4 sm:px-6 md:px-8 relative overflow-hidden">
        <WaveBackground />
        <div className="max-w-2xl w-full text-center animate-fade-in-up relative z-10">
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold mb-4 sm:mb-6" style={{ background: 'linear-gradient(135deg, #60a5fa 0%, #3b82f6 100%)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>
            AI Image Detector
          </h1>
          <p className="text-base sm:text-lg md:text-xl text-slate-300 mb-6 sm:mb-8 leading-relaxed">
            AI가 생성한 이미지와 실제 사진을 구분해주는 똑똑한 분석 도구입니다.
            <br />
            이미지를 업로드하고 AI 생성 여부를 확인하세요.
          </p>

          <div className="space-y-3 sm:space-y-4 mb-6 sm:mb-8">
            <p className="text-xs sm:text-sm text-slate-400">
              고급 LLM 기술을 활용한 정확한 분석
            </p>
            <div className="flex flex-wrap justify-center gap-2 sm:gap-3">
              <span className="px-2 sm:px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs sm:text-sm font-medium">
                드래그 앤 드롭 지원
              </span>
              <span className="px-2 sm:px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs sm:text-sm font-medium">
                URL 분석 가능
              </span>
              <span className="px-2 sm:px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs sm:text-sm font-medium">
                결과 공유 기능
              </span>
            </div>
          </div>

          <button
            onClick={() => (window.location.href = getLoginUrl())}
            className="relative px-6 sm:px-8 py-3 sm:py-4 text-base sm:text-lg font-semibold text-white overflow-hidden transition-all duration-300 hover:scale-105 active:scale-95"
            style={{
              background: 'linear-gradient(135deg, #3b82f6 0%, #60a5fa 100%)',
              borderRadius: '0.75rem',
              border: '1px solid rgba(96, 165, 250, 0.5)',
              boxShadow: '0 0 30px rgba(59, 130, 246, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.2)',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.boxShadow = '0 0 50px rgba(59, 130, 246, 0.6), 0 0 80px rgba(96, 165, 250, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.2)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.boxShadow = '0 0 30px rgba(59, 130, 246, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.2)';
            }}
          >
            <span className="relative z-10">로그인하여 시작하기</span>
          </button>
        </div>
      </div>
    );
  }

  // Render main app
  return (
    <>
      <ProUpgradeModal
        isOpen={showProModal}
        onClose={() => setShowProModal(false)}
      />
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5">
      {/* Header */}
      <header className="border-b border-muted bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container px-4 sm:px-6 md:px-8 py-3 sm:py-4 flex items-center justify-between">
          <div>
            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold gradient-text">AI Image Detector</h1>
            <p className="text-xs sm:text-sm text-muted-foreground">AI vs Real 이미지 판별 도구</p>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-sm text-muted-foreground">{user?.name || "사용자"}</span>
            <Button
              variant="ghost"
              size="sm"
              onClick={logout}
              className="text-muted-foreground hover:text-foreground"
            >
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container px-4 sm:px-6 md:px-8 py-6 sm:py-8 md:py-12">
        {analysisState ? (
          // Show analysis result
          <div className="animate-fade-in-up">
            <Button
              variant="ghost"
              onClick={() => setAnalysisState(null)}
              className="mb-6 text-muted-foreground hover:text-foreground"
            >
              ← 새로운 분석
            </Button>
            <AnalysisResult
              aiProbability={analysisState.aiProbability}
              confidence={analysisState.confidence}
              analysis={analysisState.analysis}
              imageUrl={analysisState.imageUrl}
              analysisId={analysisState.id}
              onShare={handleShare}
              isSharing={createShareMutation.isPending}
            />
          </div>
        ) : (
          // Show upload/analysis interface
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-8 sm:mb-10 md:mb-12 animate-fade-in-down">
              <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold mb-3 sm:mb-4">
                이미지를 분석하세요
              </h2>
              <p className="text-base sm:text-lg text-muted-foreground">
                AI 생성 이미지와 실제 사진을 정확하게 구분해드립니다
              </p>
            </div>

            {/* Tabs for upload and URL */}
            <Tabs defaultValue="upload" className="mb-8 sm:mb-10 md:mb-12">
              <TabsList className="grid w-full grid-cols-2 mb-6 sm:mb-8">
                <TabsTrigger value="upload">이미지 업로드</TabsTrigger>
                <TabsTrigger value="url">URL 입력</TabsTrigger>
              </TabsList>

              <TabsContent value="upload" className="animate-fade-in-up">
                <ImageUploadZone
                  onImageSelect={handleImageUpload}
                  isLoading={isAnalyzing}
                />
              </TabsContent>

              <TabsContent value="url" className="animate-fade-in-up">
                <Card className="p-8 rounded-2xl">
                  <UrlInputForm onSubmit={handleUrlSubmit} isLoading={isAnalyzing} />
                </Card>
              </TabsContent>
            </Tabs>

            {isAnalyzing && (
              <div className="flex flex-col items-center justify-center py-12">
                <Spinner className="w-12 h-12 mb-4" />
                <p className="text-muted-foreground">이미지를 분석 중입니다...</p>
              </div>
            )}

            {/* History Section */}
            {historyQuery.data && historyQuery.data.length > 0 && !isAnalyzing && (
              <div className="mt-16 animate-fade-in-up">
                <div className="flex items-center gap-2 mb-6">
                  <History className="w-5 h-5 text-accent" />
                  <h3 className="text-2xl font-bold">최근 분석</h3>
                </div>
                <AnalysisHistory
                  items={historyQuery.data.map((item: any) => ({
                    id: item.id,
                    imageUrl: item.imageUrl,
                    aiProbability: item.aiProbability,
                    confidence: item.confidence,
                    analysis: item.analysis,
                    createdAt: item.createdAt,
                    detectionMethod: item.detectionMethod,
                  }))}
                  onItemClick={(item) => {
                    setAnalysisState({
                      id: item.id,
                      aiProbability: item.aiProbability,
                      confidence: item.confidence,
                      analysis: item.analysis,
                      imageUrl: item.imageUrl,
                    });
                  }}
                />
              </div>
            )}
          </div>
        )}
      </main>
    </div>
    </>
  );
}

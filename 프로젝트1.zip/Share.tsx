import { useParams } from "wouter";
import { Spinner } from "@/components/ui/spinner";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertCircle, ArrowLeft } from "lucide-react";
import { AnalysisResult } from "@/components/AnalysisResult";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";

export default function Share() {
  const { shareToken } = useParams<{ shareToken: string }>();
  const [, setLocation] = useLocation();

  // Fetch shared analysis result
  const { data, isLoading, error } = trpc.analysis.getShared.useQuery(
    { shareToken: shareToken || "" },
    { enabled: !!shareToken }
  );

  if (!shareToken) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5 flex items-center justify-center px-4">
        <Card className="p-8 rounded-2xl text-center max-w-md">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">유효하지 않은 링크</h2>
          <p className="text-muted-foreground mb-6">
            공유 링크가 올바르지 않습니다.
          </p>
          <Button onClick={() => setLocation("/")} className="w-full">
            홈으로 돌아가기
          </Button>
        </Card>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5 flex items-center justify-center">
        <div className="text-center">
          <Spinner className="w-12 h-12 mb-4 mx-auto" />
          <p className="text-muted-foreground">분석 결과를 로드 중입니다...</p>
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5 flex items-center justify-center px-4">
        <Card className="p-8 rounded-2xl text-center max-w-md">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">결과를 찾을 수 없습니다</h2>
          <p className="text-muted-foreground mb-6">
            공유된 분석 결과가 더 이상 존재하지 않거나 삭제되었을 수 있습니다.
          </p>
          <Button onClick={() => setLocation("/")} className="w-full">
            홈으로 돌아가기
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5">
      {/* Header */}
      <header className="border-b border-muted bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="text-muted-foreground hover:text-foreground mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            돌아가기
          </Button>
          <div>
            <h1 className="text-2xl font-bold gradient-text">공유된 분석 결과</h1>
            <p className="text-xs text-muted-foreground">
              AI vs Real 이미지 판별 결과
            </p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8 md:py-12">
        <div className="max-w-3xl mx-auto animate-fade-in-up">
          <AnalysisResult
            aiProbability={data.aiProbability}
            confidence={data.confidence}
            analysis={data.analysis}
            imageUrl={data.imageUrl}
            analysisId={data.analysisId}
            onShare={() => {}}
            isSharing={false}
          />

          {/* Shared Info */}
          <Card className="mt-8 p-6 rounded-2xl">
            <h3 className="text-lg font-semibold mb-3">공유 정보</h3>
            <div className="space-y-2 text-sm text-muted-foreground">
              <p>
                이 분석 결과는 공개적으로 공유되었습니다. 누구나 이 링크를 통해
                결과를 확인할 수 있습니다.
              </p>
              <p className="text-xs">
                공유 날짜:{" "}
                {new Date(data.sharedAt).toLocaleDateString("ko-KR", {
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                  hour: "2-digit",
                  minute: "2-digit",
                })}
              </p>
            </div>
          </Card>
        </div>
      </main>
    </div>
  );
}

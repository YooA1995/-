import { useState } from "react";
import { Link as LinkIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface UrlInputFormProps {
  onSubmit: (url: string) => void;
  isLoading?: boolean;
}

export function UrlInputForm({ onSubmit, isLoading = false }: UrlInputFormProps) {
  const [url, setUrl] = useState("");
  const [error, setError] = useState<string | null>(null);

  const validateUrl = (urlString: string): boolean => {
    try {
      const urlObj = new URL(urlString);
      const validProtocols = ["http:", "https:"];
      if (!validProtocols.includes(urlObj.protocol)) {
        setError("HTTP 또는 HTTPS URL만 지원합니다.");
        return false;
      }
      setError(null);
      return true;
    } catch {
      setError("유효한 URL을 입력해주세요.");
      return false;
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateUrl(url)) {
      onSubmit(url);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="w-full space-y-4">
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="flex-1 relative">
          <LinkIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground pointer-events-none" />
          <Input
            type="url"
            placeholder="이미지 URL을 입력하세요 (예: https://example.com/image.jpg)"
            value={url}
            onChange={(e) => {
              setUrl(e.target.value);
              setError(null);
            }}
            disabled={isLoading}
            className="pl-12 h-12 rounded-lg"
          />
        </div>
        <Button
          type="submit"
          disabled={isLoading || !url}
          className="button button-primary h-12 px-6"
        >
          {isLoading ? "분석 중..." : "분석"}
        </Button>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
    </form>
  );
}

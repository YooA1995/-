import { Clock, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

interface AnalysisItem {
  id: number;
  imageUrl: string;
  aiProbability: number;
  confidence: number;
  analysis: string;
  createdAt: Date | string;
  detectionMethod: string;
}

interface AnalysisHistoryProps {
  items: AnalysisItem[];
  isLoading?: boolean;
  onItemClick?: (item: AnalysisItem) => void;
  onDelete?: (id: number) => void;
}

export function AnalysisHistory({
  items,
  isLoading = false,
  onItemClick,
  onDelete,
}: AnalysisHistoryProps) {
  const formatDate = (date: Date | string): string => {
    const d = typeof date === "string" ? new Date(date) : date;
    return d.toLocaleDateString("ko-KR", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const getResultLabel = (probability: number): string => {
    return probability >= 50 ? "AI 생성" : "실제 사진";
  };

  const getResultColor = (probability: number): string => {
    return probability >= 50
      ? "text-red-500 bg-red-50 dark:bg-red-950/20"
      : "text-green-500 bg-green-50 dark:bg-green-950/20";
  };

  if (isLoading) {
    return (
      <div className="space-y-3">
        {[...Array(3)].map((_, i) => (
          <Skeleton key={i} className="h-24 rounded-lg" />
        ))}
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <Card className="p-12 text-center rounded-2xl">
        <Clock className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
        <h3 className="text-lg font-semibold mb-2">분석 히스토리가 없습니다</h3>
        <p className="text-sm text-muted-foreground">
          이미지를 분석하면 여기에 결과가 저장됩니다
        </p>
      </Card>
    );
  }

  return (
    <div className="space-y-3">
      {items.map((item) => (
        <Card
          key={item.id}
          className="p-4 rounded-xl cursor-pointer transition-all hover:shadow-md hover:border-accent/50"
          onClick={() => onItemClick?.(item)}
        >
          <div className="flex items-center gap-4">
            {/* Thumbnail */}
            <div className="flex-shrink-0 w-16 h-16 rounded-lg overflow-hidden bg-muted">
              <img
                src={item.imageUrl}
                alt="Analysis"
                className="w-full h-full object-cover"
              />
            </div>

            {/* Content */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-2">
                <span
                  className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold ${getResultColor(
                    item.aiProbability
                  )}`}
                >
                  {getResultLabel(item.aiProbability)}
                </span>
                <span className="text-xs text-muted-foreground">
                  {item.aiProbability}% 확률
                </span>
              </div>
              <p className="text-sm text-muted-foreground truncate">
                {item.detectionMethod === "upload" ? "업로드된 이미지" : "URL 이미지"}
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                {formatDate(item.createdAt)}
              </p>
            </div>

            {/* Actions */}
            <div className="flex-shrink-0">
              {onDelete && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    onDelete(item.id);
                  }}
                  className="text-muted-foreground hover:text-destructive"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              )}
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
}

import { describe, it, expect, vi, beforeEach } from "vitest";
import { analyzeImage, AnalysisResult } from "./analysis";

// Mock the LLM module
vi.mock("./_core/llm", () => ({
  invokeLLM: vi.fn(),
}));

import { invokeLLM } from "./_core/llm";

describe("analyzeImage", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should return analysis result with valid structure", async () => {
    const mockResponse = {
      choices: [
        {
          message: {
            content: JSON.stringify({
              aiProbability: 75,
              confidence: 85,
              analysis:
                "The image shows characteristics typical of AI-generated content, including perfect symmetry and unrealistic lighting.",
            }),
          },
        },
      ],
    };

    (invokeLLM as any).mockResolvedValue(mockResponse);

    const result = await analyzeImage("https://example.com/image.jpg");

    expect(result).toEqual({
      aiProbability: 75,
      confidence: 85,
      analysis:
        "The image shows characteristics typical of AI-generated content, including perfect symmetry and unrealistic lighting.",
    });
  });

  it("should throw error when LLM response is invalid", async () => {
    const mockResponse = {
      choices: [
        {
          message: {
            content: "Invalid JSON",
          },
        },
      ],
    };

    (invokeLLM as any).mockResolvedValue(mockResponse);

    await expect(analyzeImage("https://example.com/image.jpg")).rejects.toThrow();
  });

  it("should throw error when response content is missing", async () => {
    const mockResponse = {
      choices: [
        {
          message: {
            content: null,
          },
        },
      ],
    };

    (invokeLLM as any).mockResolvedValue(mockResponse);

    await expect(analyzeImage("https://example.com/image.jpg")).rejects.toThrow(
      "Failed to get LLM response"
    );
  });

  it("should handle real image detection", async () => {
    const mockResponse = {
      choices: [
        {
          message: {
            content: JSON.stringify({
              aiProbability: 15,
              confidence: 92,
              analysis:
                "This appears to be a genuine photograph with natural lighting, realistic textures, and authentic details.",
            }),
          },
        },
      ],
    };

    (invokeLLM as any).mockResolvedValue(mockResponse);

    const result = await analyzeImage("https://example.com/real-photo.jpg");

    expect(result.aiProbability).toBeLessThan(50);
    expect(result.confidence).toBeGreaterThan(80);
  });

  it("should call invokeLLM with correct parameters", async () => {
    const mockResponse = {
      choices: [
        {
          message: {
            content: JSON.stringify({
              aiProbability: 50,
              confidence: 70,
              analysis: "Borderline case",
            }),
          },
        },
      ],
    };

    (invokeLLM as any).mockResolvedValue(mockResponse);

    const imageUrl = "https://example.com/test.jpg";
    await analyzeImage(imageUrl);

    expect(invokeLLM).toHaveBeenCalledWith(
      expect.objectContaining({
        messages: expect.arrayContaining([
          expect.objectContaining({
            role: "system",
          }),
          expect.objectContaining({
            role: "user",
            content: expect.arrayContaining([
              expect.objectContaining({
                type: "image_url",
                image_url: {
                  url: imageUrl,
                  detail: "high",
                },
              }),
            ]),
          }),
        ]),
        response_format: expect.objectContaining({
          type: "json_schema",
        }),
      })
    );
  });
});

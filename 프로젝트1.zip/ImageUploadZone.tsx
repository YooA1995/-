import { useState, useRef } from "react";
import { Upload, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface ImageUploadZoneProps {
  onImageSelect: (file: File) => void;
  isLoading?: boolean;
}

export function ImageUploadZone({ onImageSelect, isLoading = false }: ImageUploadZoneProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const validateFile = (file: File): boolean => {
    const validTypes = ["image/jpeg", "image/png", "image/webp", "image/gif"];
    const maxSize = 10 * 1024 * 1024; // 10MB

    if (!validTypes.includes(file.type)) {
      setError("지원하지 않는 파일 형식입니다. (JPG, PNG, WebP, GIF만 가능)");
      return false;
    }

    if (file.size > maxSize) {
      setError("파일 크기가 너무 큽니다. (최대 10MB)");
      return false;
    }

    setError(null);
    return true;
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);

    const files = e.dataTransfer.files;
    if (files.length > 0) {
      const file = files[0];
      if (validateFile(file)) {
        onImageSelect(file);
      }
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.currentTarget.files;
    if (files && files.length > 0) {
      const file = files[0];
      if (validateFile(file)) {
        onImageSelect(file);
      }
    }
  };

  const handleClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="w-full">
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={handleClick}
        className={`relative rounded-2xl border-2 border-dashed transition-all duration-300 cursor-pointer ${
          isDragging
            ? "border-accent bg-accent/5"
            : "border-muted bg-muted/30 hover:border-accent/50 hover:bg-accent/3"
        } ${isLoading ? "opacity-50 cursor-not-allowed" : ""}`}
      >
        <div className="flex flex-col items-center justify-center py-12 px-6 text-center">
          <div className={`mb-4 p-4 rounded-full ${isDragging ? "bg-accent/10" : "bg-muted"}`}>
            <Upload
              className={`w-8 h-8 transition-colors ${
                isDragging ? "text-accent" : "text-muted-foreground"
              }`}
            />
          </div>

          <h3 className="text-lg font-semibold mb-2">이미지 업로드</h3>
          <p className="text-sm text-muted-foreground mb-4">
            드래그 앤 드롭으로 이미지를 업로드하거나 클릭하여 파일을 선택하세요
          </p>

          <p className="text-xs text-muted-foreground">
            지원 형식: JPG, PNG, WebP, GIF (최대 10MB)
          </p>
        </div>

        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileSelect}
          className="hidden"
          disabled={isLoading}
        />
      </div>

      {error && (
        <Alert variant="destructive" className="mt-4">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
    </div>
  );
}

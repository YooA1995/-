import { useState } from "react";
import { Copy, Check, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";

interface AnalysisResultProps {
  aiProbability: number;
  confidence: number;
  analysis: string;
  imageUrl: string;
  analysisId: number;
  onShare?: (shareToken: string) => void;
  isSharing?: boolean;
}

export function AnalysisResult({
  aiProbability,
  confidence,
  analysis,
  imageUrl,
  analysisId,
  onShare,
  isSharing = false,
}: AnalysisResultProps) {
  const [copied, setCopied] = useState(false);
  const isAiGenerated = aiProbability >= 50;
  const resultLabel = isAiGenerated ? "AI 생성 가능성 높음" : "실제 사진 가능성 높음";
  const resultColor = isAiGenerated ? "text-red-500" : "text-green-500";
  const bgColor = isAiGenerated ? "bg-red-50 dark:bg-red-950/20" : "bg-green-50 dark:bg-green-950/20";

  const handleCopyShareLink = async () => {
    if (onShare) {
      onShare(analysisId.toString());
    }
  };

  const getConfidenceLabel = (conf: number): string => {
    if (conf >= 80) return "매우 높음";
    if (conf >= 60) return "높음";
    if (conf >= 40) return "중간";
    return "낮음";
  };

  return (
    <div className="w-full space-y-6 animate-fade-in-up">
      {/* Result Summary Card */}
      <Card className={`${bgColor} border-0 p-8 rounded-2xl`}>
        <div className="flex flex-col md:flex-row items-center gap-8">
          {/* Image Preview */}
          <div className="flex-shrink-0 w-32 h-32 md:w-40 md:h-40 rounded-xl overflow-hidden shadow-lg">
            <img
              src={imageUrl}
              alt="Analyzed"
              className="w-full h-full object-cover"
            />
          </div>

          {/* Result Content */}
          <div className="flex-1">
            <div className="mb-6">
              <p className="text-sm font-medium text-muted-foreground mb-2">분석 결과</p>
              <h3 className={`text-3xl font-bold ${resultColor} mb-2`}>{resultLabel}</h3>
              <p className="text-sm text-muted-foreground">
                AI 생성 확률: <span className="font-semibold text-foreground">{aiProbability}%</span>
              </p>
            </div>

            {/* Probability Gauge */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">신뢰도</span>
                <span className="text-sm font-semibold">{getConfidenceLabel(confidence)}</span>
              </div>
              <div className="w-full bg-muted rounded-full h-2 overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    confidence >= 70 ? "bg-green-500" : confidence >= 40 ? "bg-yellow-500" : "bg-red-500"
                  }`}
                  style={{ width: `${confidence}%` }}
                />
              </div>
            </div>

            {/* Probability Gauge */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">AI 생성 확률</span>
                <span className="text-sm font-semibold">{aiProbability}%</span>
              </div>
              <div className="w-full bg-muted rounded-full h-2 overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    aiProbability >= 70 ? "bg-red-500" : aiProbability >= 40 ? "bg-yellow-500" : "bg-green-500"
                  }`}
                  style={{ width: `${aiProbability}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Analysis Details */}
      <Card className="p-8 rounded-2xl">
        <h4 className="text-lg font-semibold mb-4">분석 근거</h4>
        <p className="text-base leading-relaxed text-muted-foreground whitespace-pre-wrap">
          {analysis}
        </p>
      </Card>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-3">
        <Button
          onClick={handleCopyShareLink}
          disabled={isSharing}
          className="flex-1 button button-primary"
        >
          <Share2 className="w-4 h-4 mr-2" />
          {isSharing ? "공유 링크 생성 중..." : "결과 공유"}
        </Button>
      </div>
    </div>
  );
}
